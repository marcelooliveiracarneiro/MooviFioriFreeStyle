/* global QUnit */

sap.ui.require([
	"moovi/zldtemplate/test/integration/AllJourneys"
], function() {
	QUnit.config.autostart = false;
	QUnit.start();
});