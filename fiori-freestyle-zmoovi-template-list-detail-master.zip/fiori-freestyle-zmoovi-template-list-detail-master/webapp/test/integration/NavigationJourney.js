/*global QUnit*/

sap.ui.define([
	"sap/ui/test/opaQunit",
	"./pages/List",
	"./pages/Detail",
	"./pages/App"
], function (opaTest) {
	"use strict";

	QUnit.module("Desktop navigation");

});